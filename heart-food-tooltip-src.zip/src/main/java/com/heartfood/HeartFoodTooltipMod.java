package com.heartfood;

import com.heartfood.mixin.ClientAdvancementManagerAccessor;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.minecraft.advancement.AdvancementProgress;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientAdvancementManager;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.component.DataComponentTypes;
import net.minecraft.item.ItemStack;
import net.minecraft.item.tooltip.TooltipType;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.Identifier;

import java.util.List;
import java.util.Map;

/**
 * Heart Food Tooltip – client-side Fabric mod (1.21.5)
 * ═══════════════════════════════════════════════════════
 *
 * Pokazuje w tooltipie każdego food itemu czy gracz:
 *  ✓ Już to zjadł (czerwony tekst)  – na podstawie permanentnego tracking adv.
 *  ✗ Jeszcze nie zjadł (zielony)
 *  ~ Zjadł w tym życiu (złoty) – na podstawie life_tracking adv.
 *
 * Dane pobierane są z advancementów zsynchronizowanych przez serwer.
 * Wymaga datapacku heart_food_progression po stronie serwera/świata.
 *
 * Nie ma żadnego stanu po stronie klienta – czyste odczytanie mapy advancementów.
 */
public class HeartFoodTooltipMod implements ClientModInitializer {

    public static final String MOD_ID = "heart_food_tooltip";

    /** Namespace datapacku – musi być identyczny jak w generate_foods.py */
    private static final String DP_NS = "heart_food_progression";

    @Override
    public void onInitializeClient() {
        ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
            // ── Tylko food itemy ──────────────────────────────────────────────
            if (stack.get(DataComponentTypes.FOOD) == null) return;

            MinecraftClient client = MinecraftClient.getInstance();
            if (client.player == null) return;

            // ── Zbuduj identyfikatory advancementów dla tego itemu ────────────
            Identifier itemId   = Registries.ITEM.getId(stack.getItem());
            String     safePath = itemId.getPath().replace('/', '_');

            // permanentny – "kiedykolwiek zjedzony"
            Identifier advTracking = Identifier.of(DP_NS,
                "tracking/" + itemId.getNamespace() + "/" + safePath);

            // per-życie – "zjedzone w tym życiu"
            Identifier advLifeTracking = Identifier.of(DP_NS,
                "life_tracking/" + itemId.getNamespace() + "/" + safePath);

            // ── Odczytaj stan advancementów z serwera ────────────────────────
            boolean eatenEver = isAdvancementDone(client, advTracking);
            boolean eatenThisLife = isAdvancementDone(client, advLifeTracking);

            // ── Separator wizualny (pusta linia) ─────────────────────────────
            lines.add(Text.literal(" "));

            // ── Linia statusu ─────────────────────────────────────────────────
            if (eatenThisLife) {
                // Zjedzono w tym życiu – nie dostaniesz już serduszka
                lines.add(
                    Text.literal("❤ Zjedzone w tym życiu")
                        .formatted(Formatting.GOLD)
                );
                lines.add(
                    Text.literal("  Umrzyj, żeby zdobyć ponownie")
                        .formatted(Formatting.DARK_GRAY, Formatting.ITALIC)
                );
            } else if (eatenEver) {
                // Zjedzone kiedyś, ale nie w tym życiu → można zdobyć serce
                lines.add(
                    Text.literal("✓ Już to jadłeś")
                        .formatted(Formatting.RED)
                );
                lines.add(
                    Text.literal("  +❤ jeśli zjesz w tym życiu!")
                        .formatted(Formatting.DARK_RED, Formatting.ITALIC)
                );
            } else {
                // Nigdy nie jedzone
                lines.add(
                    Text.literal("✗ Jeszcze tego nie jadłeś")
                        .formatted(Formatting.GREEN)
                );
                lines.add(
                    Text.literal("  +❤ zdobądź nowe serduszko!")
                        .formatted(Formatting.DARK_GREEN, Formatting.ITALIC)
                );
            }
        });
    }

    /**
     * Sprawdza stan danego advancement'u w mapie synchronizowanej przez serwer.
     *
     * @param client aktywny klient Minecraft
     * @param advId  Identifier advancement'u do sprawdzenia
     * @return true jeśli advancement jest ukończony (isDone)
     */
    private static boolean isAdvancementDone(MinecraftClient client, Identifier advId) {
        try {
            ClientPlayNetworkHandler networkHandler = client.getNetworkHandler();
            if (networkHandler == null) return false;

            ClientAdvancementManager manager = networkHandler.getAdvancementHandler();
            if (manager == null) return false;

            // Dostęp przez Mixin Accessor do prywatnej mapy progresów
            Map<Identifier, AdvancementProgress> progresses =
                ((ClientAdvancementManagerAccessor) manager).getAdvancementProgresses();
            if (progresses == null) return false;

            AdvancementProgress progress = progresses.get(advId);
            return progress != null && progress.isDone();

        } catch (Exception ignored) {
            // Tooltip nigdy nie może crashować gry – ciche pominięcie
            return false;
        }
    }
}
