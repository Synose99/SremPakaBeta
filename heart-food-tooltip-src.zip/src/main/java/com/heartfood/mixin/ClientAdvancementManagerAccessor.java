package com.heartfood.mixin;

import net.minecraft.advancement.AdvancementProgress;
import net.minecraft.client.network.ClientAdvancementManager;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.Map;

/**
 * Accessor Mixin do ClientAdvancementManager.
 *
 * Daje dostęp do prywatnej mapy {@code advancementProgresses} (Yarn mapping),
 * która przechowuje stan advancementów zsynchronizowany z serwera.
 *
 * Jeśli po aktualizacji Yarn nazwa pola się zmieni, zaktualizuj wartość
 * @Accessor i zremapuj za pomocą: ./gradlew remapJar
 */
@Mixin(ClientAdvancementManager.class)
public interface ClientAdvancementManagerAccessor {

    /**
     * @return mapa: Identifier advancement'u → jego AdvancementProgress (klient)
     */
    @Accessor("advancementProgresses")
    Map<Identifier, AdvancementProgress> getAdvancementProgresses();
}
